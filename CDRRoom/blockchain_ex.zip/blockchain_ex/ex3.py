### import any built-in Python module you need

def blockchain(blocks_dir, IV):
    md5_str = ''
    
    ### ADD YOUR CODE HERE

    return md5_str